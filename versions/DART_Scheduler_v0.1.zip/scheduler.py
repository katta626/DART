import json
import time
import os
from pulsar_info import RA
import datetime

FILE_PATH = "pulsar_schedule.json"
FILE_PATH_1 = "status.json"
THRESHOLD_SECONDS = 100  # Set your execution threshold

# Define which messages to show (keywords)
FILTER_KEYWORDS = ["Waiting for", "Observation", "Pulsar:","ACQ over","Removing Trigger file from remote machine","Observation stoped","SLIP check","Pulsar data reduction pipeline started ...","---","All done!"]  # only show lines containing these



def load_schedule():
    if os.path.exists(FILE_PATH):
        with open(FILE_PATH, "r") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return {}
    return {}

def save_schedule(schedule):
    with open(FILE_PATH, "w") as f:
        sorted_items = dict(
            sorted(
                schedule.items(),
                key=lambda item: item[1]["system_data"].get("Count Down", float("inf"))
            )
        )
        json.dump(sorted_items, f, indent=4)

def save_status(status):
    with open(FILE_PATH_1, "w") as f:
        json.dump(status, f, indent=4)

def load_status():
    if os.path.exists(FILE_PATH_1):
        with open(FILE_PATH_1, "r") as f:
            try:

                return json.load(f)
            except json.JSONDecodeError:
                return {}
    return {}

def read_all_lines(file_path):
    """Read all lines from the log file"""
    if not os.path.exists(file_path):
        return []
    with open(file_path, "r") as f:
        return [line.strip() for line in f.readlines()]

def filter_lines(lines, keywords):
    """Keep only lines containing any of the keywords"""
    if not keywords:
        return lines  # no filtering
    return [line for line in lines if any(k in line for k in keywords)]

def trigger_observation(pulsar, num_files, trigger_time):
 
    observation_script = "/home/dsp/PDR_acquire_setup/GBD_DART_lite_obs_script_V5_IQUV_FITS_09_09_2025.sh"
 
    start_screen =  "ssh -X dsp@172.17.20.210 screen -dmS "+'"'+ str(pulsar)+'"'
    end_screen   =  "ssh -X dsp@172.17.20.210 screen -S "+'"'+ str(pulsar)+'"'+ " -X  quit"
    obs_trigger_cmd = "ssh -X dsp@172.17.20.210 "+'"screen -R '+'"'+ str(pulsar)+'"' +" -X stuff "+"'"+ str(observation_script)+ " " +str(num_files) + " "+ str(pulsar) + " " +str(trigger_time)+" ^M'"+'"'
 
    os.system(end_screen)          # To kill old screen session
    os.system(start_screen)        # To Start new screen session
    os.system(obs_trigger_cmd)     # Execute commands in new screen session


def main():
    while True:
        schedule = load_schedule()
        status_data = load_status()
        changed = False

        for pulsar, data in schedule.items():
            system_data = data.get("system_data", {})
            countdown = system_data.get("Count Down")
            status = system_data.get("status", "Not Started")
            #print(countdown)
            if countdown is not None and status != "Not Started":
                time_val = schedule["J1740+1311"]["system_data"]["Transit Time"]
                time_val = time_val.split()
                name = pulsar + "_" + time_val[0] + "_" + "observation.log"

                log_files = status_data.get("Log_Current", {}).get("current_file", [])

                for log_file in log_files:
                    file_path = os.path.join("log_files", log_file)
                    all_lines = read_all_lines(file_path)

                    parts = log_file.split("_")
                    pulsar_name = parts[0] if parts else "Unknown"
                    if "Observation Over." in all_lines[-1]:
                        # Update schedule.json
                        schedule[pulsar_name]["system_data"]["status"] = "Not Started"
                        if log_file in status_data["Log_Current"]["current_file"]:
                            status_data["Log_Current"]["current_file"].remove(log_file)
                            changed = True
                        changed = True


                # Ensure "Log_Current" exists
                if "Log_Current" not in status_data:
                    status_data["Log_Current"] = {}

                # Ensure "current_file" is a list
                if not isinstance(status_data["Log_Current"].get("current_file"), list):
                    status_data["Log_Current"]["current_file"] = []

                # Append new file if not already present
                if name not in status_data["Log_Current"]["current_file"]:
                    status_data["Log_Current"]["current_file"].append(name)
                    changed = True


            if countdown is not None and status == "Not Started":
                # Update countdown using RA()
                ra_1, updated_countdown = RA(pulsar)
                new_duration = schedule[pulsar]["duration"]

                new_duration_2 = (new_duration*60)/2
                target_ist_dt = updated_countdown - new_duration_2
                schedule[pulsar]["system_data"]["Count Down"] = target_ist_dt
                schedule[pulsar]["system_data"]["Transit Time"] = ra_1.strftime('%d_%m_%Y %H:%M:%S')

                changed = True

                # Trigger if countdown is below threshold
                if updated_countdown <= THRESHOLD_SECONDS:
                    duration = schedule[pulsar]["duration"]
                    Num_files = duration*2
                    schedule[pulsar]["system_data"]["status"] = "In Progress"
                    trigger_observation(pulsar, Num_files, THRESHOLD_SECONDS)
                    changed = True

        if changed:
            save_schedule(schedule)
            save_status(status_data)

        time.sleep(1)


if __name__ == "__main__":
    main()
