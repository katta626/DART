import json
import time
import os
from pulsar_info import RA
import datetime

FILE_PATH = "pulsar_schedule.json"
THRESHOLD_SECONDS = 100  # Set your execution threshold



def load_schedule():
    if os.path.exists(FILE_PATH):
        with open(FILE_PATH, "r") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return {}
    return {}

def save_schedule(schedule):
    with open(FILE_PATH, "w") as f:
        json.dump(schedule, f, indent=4)

def trigger_pulsar_action(pulsar_name):
    print(f"🚀 Triggering action for {pulsar_name}")



def main():
    while True:
        schedule = load_schedule()
        changed = False

        for pulsar, data in schedule.items():
            system_data = data.get("system_data", {})
            countdown = system_data.get("Count Down")
            status = system_data.get("status", "Not Started")
            #print(countdown)

            if countdown is not None and status == "Not Started":
                # Update countdown using RA()
                ra_1, updated_countdown = RA(pulsar)
                new_duration = schedule[pulsar]["duration"]

                new_duration_2 = (new_duration*60)/2
                target_ist_dt = ra_1 + datetime.timedelta(seconds=new_duration_2)
                ra = target_ist_dt.strftime('%m-%d %H:%M:%S')
                schedule[pulsar]["system_data"]["Count Down"] = updated_countdown
                schedule[pulsar]["system_data"]["Transit Time"] = ra

                changed = True

                # Trigger if countdown is below threshold
                if updated_countdown <= THRESHOLD_SECONDS:
                    duration = schedule[pulsar]["duration"]
                    No_Packets = duration*30
                    os.system()
                    schedule[pulsar]["system_data"]["status"] = "In Progress"
                    changed = True

        if changed:
            save_schedule(schedule)

        time.sleep(1)


if __name__ == "__main__":
    main()
