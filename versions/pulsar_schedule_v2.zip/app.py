import streamlit as st
import json
import os
from pulsar_info import RA
import datetime
import subprocess
import sys
import atexit

if "proc" not in st.session_state:
    st.session_state.proc = None

start = st.button("Start")
stop = st.button("Stop")

script_path = os.path.join(os.getcwd(), "scheduler.py")

if start:
    if st.session_state.proc is None or st.session_state.proc.poll() is not None:
        st.session_state.proc = subprocess.Popen([sys.executable, script_path])
        st.success("Started subprocess.")

if stop:
    if st.session_state.proc is not None:
        st.session_state.proc.terminate()
        st.session_state.proc.wait()
        st.session_state.proc = None
        st.warning("Stopped subprocess.")

# Function to clean up subprocess on exit
def cleanup():
    proc = st.session_state.get("proc")
    if proc is not None and proc.poll() is None:
        proc.terminate()
        proc.wait()

atexit.register(cleanup)


FILE_PATH = "pulsar_schedule.json"

def load_schedule():
    if os.path.exists(FILE_PATH):
        with open(FILE_PATH, "r") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return {}
    return {}

def save_schedule(schedule):
    with open(FILE_PATH, "w") as f:
        json.dump(schedule, f, indent=4)

def main():
    st.title("Pulsar Observation Scheduler")

    if 'edit_pulsar' not in st.session_state:
        st.session_state.edit_pulsar = None

    schedule = load_schedule()

    st.subheader("Current Schedule")

    if schedule:
        st.markdown("""
            <style>
            .custom-table th, .custom-table td {
                padding: 8px 12px;
                text-align: center;
            }
            </style>
        """, unsafe_allow_html=True)

        # Table Header
        cols = st.columns([2, 2, 2, 2, 1, 1])
        headers = ["Pulsar", "Duration", "Status", "Transit Time", "Edit", "Delete"]
        for col, header in zip(cols, headers):
            col.markdown(f"**{header}**")

        for pulsar in list(schedule.keys()):
            details = schedule[pulsar]
            duration = details.get("duration", "N/A")
            system_data = details.get("system_data", {})
            status = system_data.get("status", "Not Started")
            Transit_Time = system_data.get("Transit Time", "Unknown")

            col1, col2, col3, col4, col5, col6 = st.columns([2, 2, 2, 2, 1, 1])
            col1.write(pulsar)
            col2.write(duration)
            col3.write(status)
            col4.write(Transit_Time)

            if col5.button("✏️", key=f"edit_{pulsar}"):
                st.session_state.edit_pulsar = pulsar

            if col6.button("🗑️", key=f"delete_{pulsar}"):
                del schedule[pulsar]
                save_schedule(schedule)
                st.success(f"Deleted '{pulsar}'")
                st.rerun()
    else:
        st.info("No scheduled pulsars yet.")


    # Add new pulsar
    with st.expander("➕ Add Pulsar", width = 200):
        new_pulsar_name = st.text_input("New Pulsar Name")
        new_duration = st.number_input("New Duration (minutes)", min_value=1, step=1)

        if st.button("Add Pulsar"):
            if not new_pulsar_name.strip():
                st.error("Please enter a valid pulsar name.")
            elif new_pulsar_name.strip() in schedule:
                st.error("Pulsar already exists. Use Edit instead.")
            else:
                new_pulsar_name = new_pulsar_name.strip()

                new_duration_2 = (new_duration*60)/2

                ra_1,countdown = RA(new_pulsar_name) 
                
                target_ist_dt = ra_1 + datetime.timedelta(seconds=new_duration_2)
                ra = target_ist_dt.strftime('%m-%d %H:%M:%S')
                # Your RA() function
                system_data = {
                    "status": "Not Started",
                    "Transit Time": ra,
                    "Count Down":countdown,
                }
                schedule[new_pulsar_name] = {
                    "duration": new_duration,
                    "system_data": system_data
                }
                save_schedule(schedule)
                st.success(f"Added pulsar '{new_pulsar_name}'.")
                st.rerun() 

        # Edit form below table
    if 'edit_pulsar' in st.session_state and st.session_state.edit_pulsar:
        pulsar = st.session_state.edit_pulsar
        details = schedule[pulsar]
        duration = details.get("duration", 1)

        st.markdown("---")
        st.subheader(f"Edit Schedule: {pulsar}")
        new_duration = st.number_input("Duration (minutes)", min_value=1, value=duration)

        if st.button("Update Schedule"):
            system_data = details.get("system_data", {"status": "Not Started", "Transit Time": "Unkown"})
            schedule[pulsar] = {
                "duration": new_duration,
                "system_data": system_data
            }
            save_schedule(schedule)
            st.success(f"Updated schedule for '{pulsar}'.")
            st.session_state.edit_pulsar = None
            st.rerun()

if __name__ == "__main__":
    main()
