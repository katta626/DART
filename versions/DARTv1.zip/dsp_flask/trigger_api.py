from flask import Flask, request
import os
from flask import jsonify, send_file
log_files = "log_files"
app = Flask(__name__)

@app.route('/trigger', methods=['POST'])
def trigger_observation():
    data = request.json
    print("Received parameters:", data)
    print(type(data))
    # Run your observation code here
    run_observation(data)
    
    return {"status": "observation started"}, 200

def run_observation(params):
    print("Running observation with:", params)
    # Example: call shell scripts, trigger scheduler, etc.
    

@app.route('/get-log', methods=['GET'])
def get_log_file():
    filename = request.args.get("filename")
    if not filename:
        return jsonify({"error": "Filename parameter missing"}), 400

    safe_filename = os.path.basename(filename)
    log_path = os.path.join(log_files, safe_filename)

    if os.path.exists(log_path):
        return send_file(log_path, as_attachment=True)
    else:
        return jsonify({"error": "Log file not found"}), 404
        

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=6000)  # open to all IPs on port 5000
