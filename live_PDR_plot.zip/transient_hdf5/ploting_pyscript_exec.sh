#!/bin/bash

dir2plot=$1
plotting_pyscript=/home/summer/Pictures/transient_hdf5/PDR_DEBUG_phase_check_plot_spectrum_allxCC_in_HDF5_04_07_2024.py
hdf5_comine_script=/home/summer/Pictures/transient_hdf5/combine_all_PDR_hdf5_files_with_PA_08_01_2024.py
plot_combined_data=/home/summer/Pictures/transient_hdf5/PDR_phase_cal_freq_axis_plot_spectrum_from_HDF5_allxCC_PA_linear_scale_single_CH_09_03_2024.py
combined_data=/home/summer/Pictures/transient_hdf5/temp_data/combined_HDF5.hdf5
one_hr_plot=/home/summer/Pictures/transient_hdf5/plots/combined_1hr_plot/one_hr_plot.png

x=1

Current_hr=$(date +%H)
last_Hr=$(($Current_hr))

cd /home/summer/Pictures/transient_hdf5/temp_data

while [ $x -le 5 ]
do
    file2plot=`ls -ltrh $dir2plot/*.hdf5 | tail -n 1 | awk '{print $9}'`
    
    python3 $plotting_pyscript $file2plot
    
    sleep 1
    
    Current_hr=$(date +%H)
    if [ $Current_hr -ne $last_Hr ]
    then
        rm -rf $combined_data
        
        python3 $hdf5_comine_script $dir2plot $combined_data 
        
        python3 $plot_combined_data $combined_data $one_hr_plot 50 200
        
        last_Hr=$Current_hr
    fi        
done



