#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 16_12_2023

@author: Arul
"""

# for Interferometry

import numpy as np
#from scipy import io as sio
#import matplotlib.pyplot as plt
import os, sys, glob, h5py
from datetime import datetime
from progress.bar import IncrementalBar


parent_dir = sys.argv[1] #"/home/summer/CAS_A_14_12_2023_17_23" #str(sys.argv[1])
file_list = list(filter(os.path.isfile, glob.glob(parent_dir +"/*.hdf5")))
file_list.sort(key=lambda x: os.path.getmtime(x))

#file_list = file_list[:2]


# ----------------- for processing bar ------------------------

class FancyBar(IncrementalBar):
    message = 'Loading'
    fill = '*'
    suffix = '%(percent).1f%% - %(eta)ds / %(elapsed)ds Elapsed'  #   
    
bar = FancyBar('Multi2Single HDF5_file ', max=int(len(file_list)))		

# ----------------- for processing bar ------------------------

out_data_file_name = 'combined_HDF5_with_PA_'+(file_list[0].rsplit('/')[-1]).rsplit('.')[1]+'_Spec_Avg.hdf5'

hdf5_file = h5py.File(out_data_file_name, 'a')

for file_no in range(len(file_list)):
    
    temp_file = h5py.File(file_list[file_no], 'r')
    corr_spec_avg =  np.array(temp_file['corr_spec_avg'])
    timestamp =  np.array(temp_file['timestamp'])
    acorr_spec_avg1 = np.array(temp_file['acorr_spec_avg1']) 
    acorr_spec_avg2 = np.array(temp_file['acorr_spec_avg2'])
    p_sum_avg = np.array(temp_file['p_sum_avg'])

    if file_no == 0 :
        hdf5_file.create_dataset('corr_spec_avg', data=corr_spec_avg, chunks=True, maxshape=(None, corr_spec_avg.shape[1]))
        hdf5_file.create_dataset('timestamp', data=timestamp, dtype='float', chunks=True, maxshape=(None,))
        hdf5_file.create_dataset('acorr_spec_avg1', data=acorr_spec_avg1, chunks=True, maxshape=(None, acorr_spec_avg1.shape[1]))
        hdf5_file.create_dataset('acorr_spec_avg2', data=acorr_spec_avg2, chunks=True, maxshape=(None, acorr_spec_avg2.shape[1]))
        hdf5_file.create_dataset('p_sum_avg', data=p_sum_avg, chunks=True, maxshape=(None, p_sum_avg.shape[1]))
        
    else:
        hdf5_file['corr_spec_avg'].resize((hdf5_file['corr_spec_avg'].shape[0] + corr_spec_avg.shape[0]), axis=0)
        hdf5_file['corr_spec_avg'][-corr_spec_avg.shape[0]:] = corr_spec_avg
        hdf5_file['timestamp'].resize((hdf5_file['timestamp'].shape[0] + timestamp.shape[0]), axis=0)
        hdf5_file['timestamp'][-timestamp.shape[0]:] = timestamp  
        hdf5_file['acorr_spec_avg1'].resize((hdf5_file['acorr_spec_avg1'].shape[0] + acorr_spec_avg1.shape[0]), axis=0)
        hdf5_file['acorr_spec_avg1'][-acorr_spec_avg1.shape[0]:] = acorr_spec_avg1
        hdf5_file['acorr_spec_avg2'].resize((hdf5_file['acorr_spec_avg2'].shape[0] + acorr_spec_avg2.shape[0]), axis=0)
        hdf5_file['acorr_spec_avg2'][-acorr_spec_avg2.shape[0]:] = acorr_spec_avg2
        hdf5_file['p_sum_avg'].resize((hdf5_file['p_sum_avg'].shape[0] + p_sum_avg.shape[0]), axis=0)
        hdf5_file['p_sum_avg'][-p_sum_avg.shape[0]:] = p_sum_avg

    bar.next()									# Progress bar
bar.finish()

