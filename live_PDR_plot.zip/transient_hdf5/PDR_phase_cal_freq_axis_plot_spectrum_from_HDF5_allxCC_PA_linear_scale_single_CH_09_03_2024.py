#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 16_12_2023

@author: Arul
"""

# for Interferometry

import numpy as np
#from scipy import io as sio
import matplotlib.pyplot as plt
import os, sys, glob, h5py
from datetime import datetime

file_name = sys.argv[1] #"/home/summer/data/gbd_obs_data_archive/test002.pcap_23_12_2023_04_28_1703285902.mbr_32226_Spec_Avg.hdf5" #"ch00_SUN_20231216_110001_001_6540_Spec_Avg.hdf5"# "ch00_CAS_A_20231214_172344_001_6540_Spec_Avg.hdf5"

plot_location = sys.argv[2]

phase_cal_file_name = "/home/summer/data/gbd_obs_data_archive/rf_path_phase.dat"

start_nchan = int(sys.argv[3])
stop_nchan  = int(sys.argv[4])
#start_nchan2 = int(sys.argv[4])
#stop_nchan2  = int(sys.argv[5])
#start_nchan3 = int(sys.argv[6])
#stop_nchan3  = int(sys.argv[7])

hdf5_file = h5py.File(file_name, 'r')

corr_spec_avg =  np.array(hdf5_file['corr_spec_avg'])
p_sum_avg =  np.array(hdf5_file['p_sum_avg'])

timestamp =  np.array(hdf5_file['timestamp'])
time = np.array(list(map(lambda Tstamp: datetime.fromtimestamp(Tstamp) , timestamp)))

#time_vs_power = np.mean(power[:,120:130], axis=1)

# ------------------------ Phase calibration -------------------------

phase_input = np.loadtxt(phase_cal_file_name, dtype="f16", delimiter=",")

rotate = 1j**(phase_input/90) 		# Phase rotation

#rotate = rotate[120:130]

phase_calib = corr_spec_avg * rotate

corr_spec_avg = phase_calib         # phase not added

# ------------------------ Phase calibration -------------------------


corr_spec_avg1		= corr_spec_avg[:,start_nchan:stop_nchan]
#corr_spec_avg2		= phase_calib[:,start_nchan2:stop_nchan2]
p_sum_avg		= p_sum_avg[:,start_nchan:stop_nchan]
#corr_spec_avg3		= corr_spec_avg[:,start_nchan3:stop_nchan3]

corr_spec_chan_avg1 	= np.mean(corr_spec_avg1, axis=1)
#corr_spec_chan_avg2 	= np.mean(corr_spec_avg2, axis=1)
p_sum_avg		= np.mean(p_sum_avg, axis=1)
#corr_spec_chan_avg3 	= np.mean(corr_spec_avg3, axis=1)

phase1    		= np.rad2deg(np.angle(corr_spec_chan_avg1))
#phase2    		= np.rad2deg(np.angle(corr_spec_chan_avg2))
#phase3    		= np.rad2deg(np.angle(corr_spec_chan_avg3))
power    		= 10*np.log10(np.abs(corr_spec_avg1)**2)
band_pass 		= np.mean(corr_spec_avg1, axis=0)

freq = 200
bw = 16.5
nchan = 256
#freq_axis = np.linspace((freq-bw/2), (freq+bw/2), nchan )

bin_size = ( bw / nchan)

freq_start = (freq-bw/2) + start_nchan * bin_size
freq_stop = (freq-bw/2) + stop_nchan * bin_size

nchan_span = stop_nchan - start_nchan

freq_axis = np.linspace(freq_start , freq_stop, nchan_span )


 # ----------- plotting

plt.subplot(5,1,1)

plt.title(file_name +' - '+ str(start_nchan)+ ':' + str(stop_nchan))
#plt.plot(freq_axis, 10*np.log10(np.abs(band_pass)**2))
#plt.ylabel('Arb. Power')
#plt.xlabel('Frequency (MHz)')
#plt.plot(time, 10*np.log10(np.abs(corr_spec_chan_avg)))
plt.plot(time, p_sum_avg)
#plt.plot(time, (corr_spec_chan_avg1.real)**2)
plt.ylabel('PA Power')
plt.xlabel('Time')
plt.grid()

plt.subplot(5,1,2)

#plt.title(file_name +' - '+ str(start_nchan)+ ':' + str(stop_nchan))
#plt.plot(freq_axis, 10*np.log10(np.abs(band_pass)**2))
#plt.ylabel('Arb. Power')
#plt.xlabel('Frequency (MHz)')
#plt.plot(time, 10*np.log10(np.abs(corr_spec_chan_avg)))
plt.plot(time, np.abs(corr_spec_chan_avg1)**2)
#plt.plot(time, (corr_spec_chan_avg1.real)**2)
plt.ylabel('Corr Power')
plt.xlabel('Time')
plt.grid()

plt.subplot(5,1,3)
plt.plot(time, corr_spec_chan_avg1.real)
plt.plot(time, corr_spec_chan_avg1.imag)
#plt.plot(time, corr_spec_chan_avg2.real)
#plt.plot(time, corr_spec_chan_avg2.imag)
#plt.plot(time, corr_spec_chan_avg3.real)
#plt.plot(time, corr_spec_chan_avg3.imag)
plt.legend(["Re1","Im1"]) #,"Re2","Im2","Re3","Im3"])
plt.ylabel('Arb. Power')
plt.xlabel('Time [MM-DD HH]')
plt.grid()

plt.subplot(5,1,4)

#extent = np.min(time), np.max(time), np.max(freq_axis), np.min(freq_axis) 

plt.imshow(np.transpose(power), aspect='auto')#, extent = extent)
#plt.ylabel('Frequency')
plt.ylabel('Freq. bins')
plt.xlabel('Time')
plt.grid()

plt.subplot(5,1,5)

plt.plot(time, phase1, '.')
#plt.plot(time, phase2, '.')
#plt.plot(time, phase3, '.')
plt.hlines(0, np.min(time), np.max(time), 'r')
#plt.legend(["Ph1"]) #,"Ph2","Ph3"])
plt.ylabel('Phase')
plt.xlabel('Time [MM-DD HH]')
plt.grid()

#figure_name = file_name + ".png"
plt.savefig(plot_location, dpi=400)
#plt.show()


"""
time_vs_power_1 = np.mean(power[:,20:30], axis=1)
time_vs_power_2 = np.mean(power[:,120:130], axis=1)
time_vs_power_3 = np.mean(power[:,226:236], axis=1)
plt.plot(time, time_vs_power_1)
plt.plot(time, time_vs_power_2)
plt.plot(time, time_vs_power_3)
#plt.vlines(np.max(time_vs_power), , 'r')
plt.ylabel('Arb. Power')
plt.xlabel('Time')

"""
