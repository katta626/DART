#!/bin/bash

source_dir=$1 #/data/PDR_data_archive/18_07_2024_14_55 
SOURCE=vela@172.17.20.203:$source_dir
Remote_machine=vela@172.17.20.203

temp_dir=$2 #~/transient_hdf5_data
#mkdir $temp_dir

Remote_FILELIST=$temp_dir/remote_fileList.txt
Local_FILELIST=$temp_dir/local_fileList.txt

x=1
NFILES2KEEP=120

#ssh $Remote_machine ls -ltrh $source_dir | tail -n 13 | head -n 10  | basename -a  $(awk '{print $9}') > remote_fileList

while [ $x -le 5 ]
do
    ssh $Remote_machine ls -ltrh $source_dir | tail -n 13 | basename -a  $(awk '{print $9}') > $Remote_FILELIST
    
    rsync -avP --files-from=$Remote_FILELIST $SOURCE/ $temp_dir/
    
    rm $temp_dir/*.PCAP_PDR_32226_Spec_Avg_allX.hdf5
    
    ls -ltrh $temp_dir/*.hdf5 | basename -a  $(awk '{print $9}') > $Local_FILELIST

    #cat $Local_FILELIST
    sleep 10
    # suffix="_$(date +%d_%m_%Y_%H_%M_%s).PCAP_PDR"
    # delete the oldest file when there are more than $NFILES2KEEP files in the 70 GB ine th Transient budffer

    if [ $(cat $Local_FILELIST | wc -l) -ge $NFILES2KEEP ]
    then
       file2Delete=`ls -lth $temp_dir/*.hdf5 | tail -n 1 | awk '{print $9}'`; echo $file2Delete
       echo -n removing the oldest file $file2Delete   ... 
       #echo rm -rf $file2Delete
       rm -rf $file2Delete
       echo done    
    fi
done

