#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 16_12_2023

@author: Arul


"""

# for Interferometry

import numpy as np
#from scipy import io as sio
import matplotlib.pyplot as plt
import os, sys, glob, h5py
from datetime import datetime

file_name = sys.argv[1] #"/home/summer/data/gbd_obs_data_archive/03_01_2024/test002.pcap_04_01_2024_13_06_1704353808.PCAPmbr_1_32226_Spec_Avg_allX.hdf5" #"/home/summer/Documents/PDR_DATA_POST_PROC/combined_HDF5_pcap_29_12_2023_11_00_1703827816_Spec_Avg.hdf5" 

no_of_spec_to_plot = 50 #19104 #int(sys.argv[3])


hdf5_file = h5py.File(file_name, 'r')

corr_spec_avg =  np.array(hdf5_file['corr_spec_avg'])

acorr_spec_avg1 =  np.array(hdf5_file['acorr_spec_avg1'])
acorr_spec_avg2 =  np.array(hdf5_file['acorr_spec_avg2'])

timestamp =  np.array(hdf5_file['timestamp'])
time = list(map(lambda Tstamp: datetime.fromtimestamp(Tstamp) , timestamp))

#corr_spec_avg   = corr_spec_avg[:,120:130]
#acorr_spec_avg1 = acorr_spec_avg1[:,120:130]
#acorr_spec_avg2 = acorr_spec_avg2[:,120:130]

corr_spec_chan_avg = np.mean(corr_spec_avg, axis=1)

band_pass = np.mean(corr_spec_avg, axis=0)
phase    = np.rad2deg(np.angle(corr_spec_chan_avg))
power    = 10*np.log10(np.abs(corr_spec_avg)**2)
band_pass_pwr = 10*np.log10(np.abs(band_pass)**2)
#time_vs_power = np.mean(power[:,120:130], axis=1)
 
"""
# ----------------------- Phase calibration ----------------------------------

phase_hdf5_file = h5py.File(phase_cal_file_name, 'r')

phase_corr_spec_avg =  np.array(phase_hdf5_file['corr_spec_avg'])

transit_timestamp =  np.array(phase_hdf5_file['timestamp'])
transit_time = list(map(lambda Tstamp: datetime.fromtimestamp(Tstamp) , transit_timestamp))

sun_transit_time 	= transit_time[33]
sun_transit_sample 	= phase_corr_spec_avg[33]
sun_transit_phase 	= np.rad2deg(np.angle(corr_spec_avg[33]))
#calc_phase = sun_transit_phase - max(sun_transit_phase)
#norm_phase = 90 - sun_transit_phase #calc_phase + (90-max(sun_transit_phase))
#norm_phase = sun_transit_phase #calc_phase + (90-max(sun_transit_phase))

#norm_phase = (0 - sun_transit_phase) 

#rotate = 1j**(norm_phase/90) 		# Phase rotation

#rotate = rotate[120:130]

phase_calib = corr_spec_avg #* rotate

#corr_spec_avg = phase_calib

#calibrated_phase = np.rad2deg(np.angle(phase_currected[33]))

#np.rad2deg(np.angle(sun_transit_sample[0] * rotate[0]))

#np.rad2deg(np.angle(rotate[0]))

# ---------------------- Phase calibration ----------------------------------
"""
#print("Given transit time: "+ str(sun_transit_time))

print("Total spectra in this file : " + str(corr_spec_avg.shape[0]))
print("First "+str(no_of_spec_to_plot)+ " will be ploted.")

plt.figure(1)
for idx in range(no_of_spec_to_plot):

    plt.subplot(5,1,1)
    plt.plot(10*np.log10(np.abs(acorr_spec_avg1[idx])**2))
    plt.title(str(time[idx]) +" : "+ str(idx) + " of "+ str(no_of_spec_to_plot)+ " spectrum")
    #plt.ylim(20, 125)
    plt.xlabel('Channal number')
    plt.ylabel('Power (dB)')
    plt.grid()
    
    plt.subplot(5,1,2)
    plt.plot(10*np.log10(np.abs(acorr_spec_avg2[idx])**2))
    #plt.title(str(time[idx]) +" : "+ str(idx) + " of "+ str(no_of_spec_to_plot)+ " spectrum")
    #plt.ylim(20, 125)
    plt.xlabel('Channal number')
    plt.ylabel('Power (dB)')
    plt.grid()

    plt.subplot(5,1,3)
    plt.plot(10*np.log10(np.abs(corr_spec_avg[idx])**2))
    #plt.title(str(time[idx]) +" : "+ str(idx) + " of "+ str(no_of_spec_to_plot)+ " spectrum")
    plt.ylim(20, 125)
    plt.xlabel('Channal number')
    plt.ylabel('X Power (dB)')
    plt.grid()
    
    plt.subplot(5,1,4)
    # https://www.geeksforgeeks.org/python-pearson-correlation-test-between-two-variables/

    Pearson_Corr_coeff = (corr_spec_avg[idx]) / np.sqrt(acorr_spec_avg1[idx] * acorr_spec_avg2[idx]) 
    
    plt.plot(Pearson_Corr_coeff)
    #plt.plot(10*np.log10(np.abs(corr_spec_avg[idx])**2))
    #plt.title(str(time[idx]) +" : "+ str(idx) + " of "+ str(no_of_spec_to_plot)+ " spectrum")
    #plt.ylim(20, 125)
    plt.xlabel('Channal number')
    plt.ylabel('Pearson_Corr')
    plt.grid()
    
    plt.subplot(5,1,5)
    plt.plot(np.rad2deg(np.angle(corr_spec_avg[idx])), '.')
    plt.ylim(-180, 180)
    plt.xlabel('Channal number')
    plt.ylabel('Phase (deg.)')
    plt.grid()
    #plt.draw()
    plt.savefig("/home/summer/Pictures/transient_hdf5/plots/pearson_CC/Pearson_Corr_coeff.png", dpi=400)
    plt.close()    
    plt.pause(1.5)
    #plt.clf()
    
plt.figure(2)
plt.subplot(3,1,1)

plt.title(file_name)

plt.plot(time, corr_spec_chan_avg.real)
plt.plot(time, corr_spec_chan_avg.imag)
plt.ylabel('Arb. Power')
plt.xlabel('Time')
"""
plt.subplot(4,1,2)

time_vs_power_1 = np.mean(power[:,20:30], axis=1)
time_vs_power_2 = np.mean(power[:,120:130], axis=1)
time_vs_power_3 = np.mean(power[:,226:236], axis=1)
plt.plot(time, time_vs_power_1)
plt.plot(time, time_vs_power_2)
plt.plot(time, time_vs_power_3)
#plt.vlines(np.max(time_vs_power), , 'r')
plt.ylabel('Arb. Power')
plt.xlabel('Time')
"""
plt.subplot(3,1,2)

freq = 200
bw = 16.5
nchan = 256
freq_axis = np.linspace((freq-bw/2), (freq+bw/2), nchan )
extent = np.min(time), np.max(time), np.min(freq_axis), np.max(freq_axis) 

plt.imshow(np.transpose(power), aspect='auto', extent = extent)
plt.ylabel('Frequency')
plt.xlabel('Time')

plt.subplot(3,1,3)

plt.plot(time, phase)
plt.hlines(0, np.min(time), np.max(time), 'r')
plt.ylabel('Phase')
plt.xlabel('Time')

onefile_figure = "/home/summer/Pictures/transient_hdf5/plots/onefile_plot/cc_tseries_phase.png"
plt.savefig(onefile_figure, dpi=400)

plt.figure(3)

freq = 200
bw = 16.5
nchan = 256
freq_axis = np.linspace((freq-bw/2), (freq+bw/2), nchan )
extent = np.min(time), np.max(time), np.min(freq_axis), np.max(freq_axis) 

plt.imshow(np.transpose(power), aspect='auto', extent = extent)
plt.ylabel('Frequency')
plt.xlabel('Time')
spectrogram_figure = "/home/summer/Pictures/transient_hdf5/plots/spectrogram/spectrogram.png"
plt.savefig(spectrogram_figure, dpi=400)
#plt.show()
