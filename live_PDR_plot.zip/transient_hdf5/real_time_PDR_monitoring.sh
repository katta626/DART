
#https://askubuntu.com/questions/46627/how-can-i-make-a-script-that-opens-terminal-windows-and-executes-commands-in-the

temp_dir=/home/summer/Pictures/transient_hdf5/temp_data/transient_hdf5_data
rm -rf $temp_dir
sleep 2

mkdir $temp_dir

#remote_dir=/data/PDR_data_archive/18_07_2024_14_55
#local_dir=$temp_dir
#rsync_script=home/summer/Pictures/transient_hdf5/rsync_new_hdf5_files.sh

remote_dir=/media/vela/cc6f4845-ca6b-47bd-b0ab-44291550fe36/data/PDR_data_archive/11_12_2024_08_31
local_dir=$temp_dir
rsync_script=/home/summer/Pictures/transient_hdf5/rsync_new_hdf5_files.sh
ploting_pyscript=/home/summer/Pictures/transient_hdf5/ploting_pyscript_exec.sh


gnome-terminal --tab --title="Rsync HDF5 data" -- bash -c  "$rsync_script $remote_dir $temp_dir; exec bash" &&

gnome-terminal --tab --title="Watch data" -- bash -c  "watch -n 1 'ls -ltrh $temp_dir | wc -l ; ls -ltrh $temp_dir'; exec bash" &&

gnome-terminal --tab --title="Make plots" -- bash -c  "$ploting_pyscript $temp_dir ; exec bash" &&

gnome-terminal --tab --title="Streamlit server" -- bash -c  "streamlit run streamlit_PDR.py ; exec bash"

#gnome-terminal --tab --title="Rsync HDF5 data" -- bash -c  "/home/summer/Pictures/transient_hdf5/rsync_new_hdf5_files.sh /data/PDR_data_archive/18_07_2024_14_55; exec bash" &&

#gnome-terminal --tab --title="watch data" -- bash -c  "watch -n 1 'ls -ltrh /home/summer/transient_hdf5_data | wc -l ; ls -ltrh /home/summer/transient_hdf5_data'; exec bash" &&

#gnome-terminal --tab --title="plot" -- bash -c  "/home/summer/Pictures/transient_hdf5/ploting_pyscript_exec.sh $temp_dir ; exec bash"


