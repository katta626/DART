
import streamlit as st
from streamlit_autorefresh import st_autorefresh

st_autorefresh(interval= 5 * 1000, key="update_plot")  # time in milli seconds

plots_dir = "/home/summer/Pictures/transient_hdf5/plots"

pearson_CC_plot = plots_dir+"/pearson_CC/Pearson_Corr_coeff.png"
cc_tseries_phase_plot = plots_dir+"/onefile_plot/cc_tseries_phase.png"
spectrogram_plot = plots_dir+"/spectrogram/spectrogram.png"
one_hr_plot=plots_dir+"/combined_1hr_plot/one_hr_plot.png"

# ---------------------- TAB ----------------------------

st.markdown("""
<style>

	.stTabs [data-baseweb="tab-list"] {
		gap: 2px;
    }

	.stTabs [data-baseweb="tab"] {
		height: 50px;
		width: 150px;
		font-size: 50px;
        white-space: pre-wrap;
		background-color: #F0F2F6;
		border-radius: 4px 4px 0px 0px;
		gap: 1px;
		padding-top: 10px;
		padding-bottom: 10px;
    }

	.stTabs [aria-selected="true"] {
  		background-color: #FFFFFF;
	}

</style>""", unsafe_allow_html=True)

# ---------------------- TAB ----------------------------

tab1, tab2, tab3, tab4 = st.tabs(["pearson_CC", "cc_tseries_phase", "spectrogram", "one_hr_plot"])

with tab1:
    st.header("Power products, pearson_CC, Phase across freqency channel")
    st.image(pearson_CC_plot, width=900)
with tab2:
    st.header("cc_tseries_phase_plot - freq. scrunched")
    st.image(cc_tseries_phase_plot, width=900)
with tab3:
    st.header("spectrogram_plot - 1 file [30s]")
    st.image(spectrogram_plot, width=900)
with tab4:
    st.header("Last 1 Hr plot")
    st.image(one_hr_plot, width=900)
    
    
    
